import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBQ7wtjMSfCaErZAeHejgNpKmnzsiBA9ko",
            authDomain: "newspaper-azh45m.firebaseapp.com",
            projectId: "newspaper-azh45m",
            storageBucket: "newspaper-azh45m.firebasestorage.app",
            messagingSenderId: "900433968850",
            appId: "1:900433968850:web:2f0dabbc1e5c5b3a9a370b"));
  } else {
    await Firebase.initializeApp();
  }
}
