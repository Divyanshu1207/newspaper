// Export pages
export '/pages/onboarding/splash/splash_widget.dart' show SplashWidget;
export '/pages/onboarding/sign_in/sign_in_widget.dart' show SignInWidget;
export '/pages/onboarding/onboarding_slideshow/onboarding_slideshow_widget.dart'
    show OnboardingSlideshowWidget;
export '/pages/onboarding/onboarding_create_account/onboarding_create_account_widget.dart'
    show OnboardingCreateAccountWidget;
export '/pages/meals/dashboard/dashboard_widget.dart' show DashboardWidget;
export '/pages/profile/profile/profile_widget.dart' show ProfileWidget;
export '/pages/profile/edit_profile/edit_profile_widget.dart'
    show EditProfileWidget;
export '/pages/profile/support_center/support_center_widget.dart'
    show SupportCenterWidget;
export '/pages/onboarding/forgot_password/forgot_password_widget.dart'
    show ForgotPasswordWidget;
export '/pages/onboarding/onboarding/onboarding_widget.dart'
    show OnboardingWidget;
