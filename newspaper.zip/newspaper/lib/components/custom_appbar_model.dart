import '/flutter_flow/flutter_flow_util.dart';
import 'custom_appbar_widget.dart' show CustomAppbarWidget;
import 'package:flutter/material.dart';

class CustomAppbarModel extends FlutterFlowModel<CustomAppbarWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
